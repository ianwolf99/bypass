READ ME - DISCLAIMER

This executable was generated from a provided PowerShell script. Use at your own risk. No warranty or liability is assumed for any damages, misuse, or legal issues arising from its use. Review the script content before executing.

By using this file you acknowledge these terms.